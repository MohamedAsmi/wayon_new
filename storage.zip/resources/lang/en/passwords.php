<?php

return [

    'password' => 'Passwords should be at least six characters and match the confirmation.',
    'reset' => 'Password has been reset!',
    'sent' => 'Password reset link has been sent to your email.',
    'token' => 'Password reset token is invalid. Please try again.',
    'user' => "User with that e-mail address is not found.",

];
