<?php

namespace App\Http\Helpers;

use GuzzleHttp\Client;

class PaymentService
{
    protected $merchantId;
    protected $apiKey;
    protected $redirectUrl;

    public function makePayment()
    {
        
    }
  
}
