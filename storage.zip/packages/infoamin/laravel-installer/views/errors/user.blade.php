@extends('vendor.installer.layout')

@section('content')
  <div class="card">
      <div class="card-content black-text">
        <div class="center-align">
            {{trans('installer.error.invalid')}}
        </div>
      </div>
  </div>
@endsection
