<?php 
namespace Infoamin\Installer\Interfaces;

interface CurlRequestInterface {
	public function send($data);
}